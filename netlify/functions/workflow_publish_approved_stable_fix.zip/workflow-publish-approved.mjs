
import path from "path";
import { fileURLToPath } from "url";

const BASE_DIR = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..", "..");
const jsonHeaders = { "content-type": "application/json; charset=utf-8" };

function respond(data, status = 200) {
  return new Response(JSON.stringify(data, null, 2), { status, headers: jsonHeaders });
}

function safeParse(text, fallback = null) {
  try { return JSON.parse(text); } catch { return fallback; }
}

function normalizeText(v) {
  return String(v || "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .trim();
}

function slugify(v) {
  return normalizeText(v).replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
}

async function readRepoJson(relPath, github) {
  const data = await github.readFile(relPath);
  if (!data.exists) return null;
  return safeParse(data.content, null);
}

async function readLocalJson(relPath) {
  const fs = await import("fs/promises");
  try {
    const txt = await fs.readFile(path.join(BASE_DIR, relPath), "utf8");
    return JSON.parse(txt);
  } catch {
    return null;
  }
}

function findCity(citiesCfg, value) {
  const input = normalizeText(value);
  return (citiesCfg?.cities || []).find(c =>
    normalizeText(c.slug) === input || normalizeText(c.name) === input
  ) || null;
}

function findService(servicesCfg, value) {
  const input = normalizeText(value);
  return (servicesCfg?.services || []).find(s =>
    normalizeText(s.slug) === input || normalizeText(s.name) === input
  ) || null;
}

function buildRecommended(city, service) {
  const template = service.questionTemplates?.[0] || `Was kostet eine ${service.name} in {city}?`;
  const topic = template.replace(/\{city\}/g, city.name);
  const secondaryKeywords = (city.keywords || []).slice(0, 3);
  return {
    priority: 10,
    topic,
    primaryKeyword: `${service.name} ${city.name}`,
    secondaryKeywords,
    searchIntent: "informational/commercial",
    format: "FAQ",
    supportsPage: city.servicePage,
    duplicatedDecision: "create new",
    cannibalizationRisk: "low",
    matchedExisting: null
  };
}

function buildDuplicate(recommended, blogIndex) {
  const items = Array.isArray(blogIndex?.items) ? blogIndex.items : [];
  const slug = slugify(recommended.topic);
  const match = items.find(x => normalizeText(x.slug) === normalizeText(slug));
  if (match) {
    return {
      status: "update existing",
      reason: "Matching slug already exists in blog index.",
      risk: "high",
      affected: match.slug
    };
  }
  return {
    status: "create new",
    reason: "No matching slug found.",
    risk: "low",
    affected: null
  };
}

function buildWriter(city, service, recommended) {
  const slug = slugify(recommended.topic);
  const title = recommended.topic;
  return {
    title,
    metaTitle: `${title} | Perfekt Sauber Service`,
    metaDescription: `Klarer Überblick zu ${normalizeText(service.name)} in ${city.name}: Ablauf, Kosten, FAQ und schnelle Anfrage.`,
    slug,
    h1: title,
    format: recommended.format,
    primaryKeyword: recommended.primaryKeyword,
    secondaryKeywords: recommended.secondaryKeywords,
    supportsPage: recommended.supportsPage,
    outline: [
      `Was beeinflusst die Kosten einer ${service.name} in ${city.name}?`,
      `Wie läuft eine ${service.name} in ${city.name} ab?`,
      `Wann lohnt sich eine schnelle Anfrage per WhatsApp?`,
      `Häufige Fragen zur ${service.name} in ${city.name}`
    ]
  };
}

function buildGeo(city, service) {
  return {
    directAnswer: `${service.name} in ${city.name} lässt sich meist nach Aufwand, Menge und Zugang kalkulieren. Eine erste Einschätzung ist schnell per WhatsApp möglich.`,
    missingSections: [],
    quoteReadyLines: [
      `${service.name} in ${city.name} wird meist nach Menge, Zugänglichkeit und Aufwand kalkuliert.`,
      `Fotos per WhatsApp beschleunigen die erste Einschätzung deutlich.`
    ],
    faqImprovements: [
      `Was kostet eine ${service.name} in ${city.name}?`,
      `Wie schnell bekommt man einen Termin?`,
      `Welche Informationen helfen für ein genaueres Angebot?`
    ],
    semanticSuggestions: [city.name, service.name, "WhatsApp Anfrage"]
  };
}

function buildLocal(city, service) {
  return {
    localizedIntro: `${service.name} in ${city.name} und Umgebung wird oft dann angefragt, wenn es schnell, klar und ohne unnötigen Aufwand gehen soll.`,
    localAreasMentioned: [city.name, ...(city.slug === "rastatt" ? ["Baden-Baden","Gaggenau","Kuppenheim"] : [])].filter(Boolean),
    localCta: `Jetzt ${service.name} in ${city.name} per WhatsApp anfragen`,
    changedElements: ["intro", "cta", "faq", "areas", "anchors"]
  };
}

function buildLinking(city, service, recommended) {
  return {
    linksOut: [recommended.supportsPage, "preisrechner.html", "blog.html"].filter(Boolean),
    linksIn: [`${slugify(service.name)}-${slugify(city.name)}.html`, "blog.html"].filter(Boolean),
    anchorTexts: [service.name + " " + city.name, "Preisrechner", "Blog"]
  };
}

function buildConversion(city, service) {
  return {
    ctaTop: `Jetzt kostenlose Einschätzung für ${service.name} in ${city.name} anfragen`,
    ctaMiddle: "Preisorientierung in 1 Minute berechnen",
    ctaBottom: "Fotos senden und exaktes Angebot erhalten",
    microConversion: "Fotos per WhatsApp senden und schnelle Rückmeldung erhalten",
    channels: ["WhatsApp", "Preisrechner", "Telefon"]
  };
}

function buildImageSuggestions(city, service) {
  const pool = [
    city.articleImage,
    city.heroImage,
    `images/${city.slug}-storage-room.png`,
    `images/${city.slug}-wardrobe-before-after.png`,
    `images/${city.slug}-table-before-after.png`
  ].filter(Boolean);
  const uniq = [...new Set(pool)];
  return uniq.slice(0, 5).map((img, idx) => ({
    path: img,
    reason: idx === 0 ? `Beste lokale Passung für ${city.name}` : `Alternative Bildidee für ${service.name} in ${city.name}`,
    imageType: idx === 0 ? "city" : "service-detail",
    fitScore: Math.max(60, 100 - idx * 8)
  }));
}

function buildArticleHtml({ city, service, writer, geo, local, conversion, selectedImage, siteUrl }) {
  const title = writer.title;
  const canonical = `${siteUrl}/blog/${writer.slug}.html`;
  const faq = geo.faqImprovements.map(q => `<li>${q}</li>`).join("");
  const outline = writer.outline.map(h => `<h2>${h}</h2><p>${service.name} in ${city.name}: klare Infos, direkte Einschätzung und schnelle Kontaktaufnahme.</p>`).join("\n");
  const imgStyle = selectedImage ? `style="background:url('${selectedImage}') center/cover no-repeat;"` : '';
  return `<!doctype html>
<html lang="de">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1" />
<title>${writer.metaTitle}</title>
<meta name="description" content="${writer.metaDescription}" />
<link rel="canonical" href="${canonical}" />
<style>
body{font-family:Inter,Arial,sans-serif;margin:0;background:#f5f8fc;color:#122033}
.wrap{max-width:1100px;margin:0 auto;padding:24px}
.hero{padding:56px 24px;border-radius:24px;background:#1e56d2;color:#fff;overflow:hidden}
.hero.hasimg{background-blend-mode:overlay;background-color:rgba(18,32,51,.45)}
.badge{display:inline-block;padding:8px 12px;border-radius:999px;background:rgba(255,255,255,.16);font-weight:700}
.btn{display:inline-block;padding:12px 16px;border-radius:12px;font-weight:700;text-decoration:none;margin-right:10px}
.btn-green{background:#76c043;color:#fff}.btn-dark{background:#122033;color:#fff}
.card{background:#fff;border:1px solid #dde5f0;border-radius:20px;padding:20px;margin:22px 0}
</style>
</head>
<body>
<div class="wrap">
<section class="hero ${selectedImage ? 'hasimg' : ''}" ${imgStyle}>
<span class="badge">${service.name} · ${city.name}</span>
<h1>${writer.h1}</h1>
<p>${local.localizedIntro}</p>
<a class="btn btn-green" href="/preisrechner.html">${conversion.ctaMiddle}</a>
<a class="btn btn-dark" href="/${writer.supportsPage}">Zur Service-Seite</a>
</section>
<div class="card"><strong>Direkte Antwort:</strong> ${geo.directAnswer}</div>
${outline}
<div class="card"><h2>FAQ</h2><ul>${faq}</ul></div>
<div class="card"><h2>Kontakt</h2><p>${conversion.ctaTop}</p><p>${conversion.microConversion}</p></div>
</div>
</body>
</html>`;
}

function buildMarkdown({ city, service, writer, geo, local, conversion, selectedImage, siteUrl }) {
  const canonical = `${siteUrl}/blog/${writer.slug}.html`;
  return `---
title: "${writer.title}"
slug: "${writer.slug}"
city: "${city.name}"
service: "${service.name}"
canonical: "${canonical}"
image: "${selectedImage || ''}"
---

# ${writer.h1}

${local.localizedIntro}

> ${geo.directAnswer}

## ${writer.outline[0]}
${service.name} in ${city.name} wird nach Aufwand, Menge und Zugang kalkuliert.

## ${writer.outline[1]}
Fotos per WhatsApp beschleunigen die erste Einschätzung.

## FAQ
- ${geo.faqImprovements.join("\n- ")}

## CTA
${conversion.ctaTop}
`;
}

function ensureBlogIndex(indexJson) {
  return indexJson && Array.isArray(indexJson.items) ? indexJson : { items: [] };
}

function upsertBlogIndex(indexJson, entry) {
  const idx = ensureBlogIndex(indexJson);
  const items = idx.items.filter(x => normalizeText(x.slug) !== normalizeText(entry.slug));
  items.unshift(entry);
  return { items };
}

function updateSitemapXml(xml, siteUrl, slug) {
  const url = `${siteUrl}/blog/${slug}.html`;
  if (!xml || !xml.includes("<urlset")) {
    return `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n  <url><loc>${siteUrl}/</loc></url>\n  <url><loc>${siteUrl}/blog/${slug}.html</loc></url>\n</urlset>\n`;
  }
  if (xml.includes(url)) return xml;
  return xml.replace("</urlset>", `  <url><loc>${url}</loc></url>\n</urlset>`);
}

function ensurePublicationState(state) {
  return state && typeof state.count === "number" && Array.isArray(state.items) ? state : { date: "1970-01-01", count: 0, items: [] };
}

function todayIsoBerlin() {
  return new Intl.DateTimeFormat("en-CA", { timeZone: "Europe/Berlin", year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date());
}

function updatePublicationState(state, writer, city, service) {
  const today = todayIsoBerlin();
  const current = ensurePublicationState(state);
  const fresh = current.date === today ? current : { date: today, count: 0, items: [] };
  const item = {
    slug: writer.slug,
    title: writer.title,
    city: city.name,
    service: service.name,
    topic: writer.title,
    publishedAt: new Date().toISOString()
  };
  const items = fresh.items.filter(x => normalizeText(x.slug) !== normalizeText(writer.slug));
  items.unshift(item);
  return { date: today, count: items.length, items };
}

function removeApproval(pending, citySlug, serviceSlug) {
  const base = pending && Array.isArray(pending.items) ? pending : { items: [] };
  return { items: base.items.filter(x => !(normalizeText(x.city) === normalizeText(citySlug) && normalizeText(x.service) === normalizeText(serviceSlug))) };
}

function makeGithubClient() {
  const token = process.env.GITHUB_TOKEN;
  const owner = process.env.GITHUB_OWNER;
  const repo = process.env.GITHUB_REPO;
  if (!token || !owner || !repo) throw new Error("Missing GitHub env vars");
  const api = "https://api.github.com";
  const headers = {
    "authorization": `Bearer ${token}`,
    "accept": "application/vnd.github+json",
    "x-github-api-version": "2022-11-28"
  };
  return {
    owner, repo,
    async readFile(relPath) {
      const res = await fetch(`${api}/repos/${owner}/${repo}/contents/${relPath}`, { headers });
      if (res.status === 404) return { exists: false, content: null, sha: null };
      if (!res.ok) throw new Error(`GitHub read failed for ${relPath}: ${res.status}`);
      const json = await res.json();
      const content = Buffer.from(json.content || "", "base64").toString("utf8");
      return { exists: true, content, sha: json.sha };
    },
    async writeFile(relPath, content, message, sha = undefined) {
      const body = {
        message,
        content: Buffer.from(content, "utf8").toString("base64"),
        branch: "main"
      };
      if (sha) body.sha = sha;
      const res = await fetch(`${api}/repos/${owner}/${repo}/contents/${relPath}`, {
        method: "PUT",
        headers: { ...headers, "content-type": "application/json" },
        body: JSON.stringify(body)
      });
      if (!res.ok) {
        const txt = await res.text();
        throw new Error(`GitHub write failed for ${relPath}: ${res.status} ${txt}`);
      }
      return res.json();
    }
  };
}

export default async function handler(req) {
  try {
    if (req.method !== "POST") return respond({ ok: false, error: "POST only" }, 405);

    const body = await req.json().catch(() => ({}));
    const github = makeGithubClient();

    const [citiesCfg, servicesCfg, rulesCfgLocal] = await Promise.all([
      readLocalJson("agent/config/cities.json"),
      readLocalJson("agent/config/services.json"),
      readLocalJson("agent/config/workflow-rules.json")
    ]);

    const city = findCity(citiesCfg, body.city);
    const service = findService(servicesCfg, body.service);

    if (!city || !service) {
      return respond({
        ok: false,
        error: "Unknown city or service",
        city: body.city,
        service: body.service,
        acceptedCityExamples: (citiesCfg?.cities || []).map(c => c.slug),
        acceptedServiceExamples: (servicesCfg?.services || []).map(s => s.slug)
      }, 400);
    }

    const pendingFile = await github.readFile("agent/state/pending-approvals.json");
    const pendingJson = safeParse(pendingFile.content || "", { items: [] });
    const approval = (pendingJson.items || []).find(x =>
      normalizeText(x.city) === normalizeText(city.slug) &&
      normalizeText(x.service) === normalizeText(service.slug)
    );
    if (!approval) {
      return respond({ ok: false, error: "No pending approval found", city: city.slug, service: service.slug }, 400);
    }

    const blogIndexFile = await github.readFile("content/auto/blog-index.json");
    const blogIndexJson = safeParse(blogIndexFile.content || "", { items: [] });

    const publicationStateFile = await github.readFile("agent/state/publication-state.json");
    const publicationStateJson = safeParse(publicationStateFile.content || "", { date: "1970-01-01", count: 0, items: [] });

    const sitemapFile = await github.readFile("sitemap.xml");
    const sitemapXml = sitemapFile.content || "";

    const siteUrl = (process.env.NETLIFY_SITE_URL || "https://perfektsauberservice.com").replace(/\/+$/, "");
    const recommended = buildRecommended(city, service);
    const duplicate = buildDuplicate(recommended, blogIndexJson);
    const writer = buildWriter(city, service, recommended);
    const geo = buildGeo(city, service);
    const localAdaptation = buildLocal(city, service);
    const internalLinking = buildLinking(city, service, recommended);
    const leadConversion = buildConversion(city, service);

    const selectedImage = approval.selectedImage || city.articleImage || city.heroImage || "";
    const html = buildArticleHtml({ city, service, writer, geo, local: localAdaptation, conversion: leadConversion, selectedImage, siteUrl });
    const md = buildMarkdown({ city, service, writer, geo, local: localAdaptation, conversion: leadConversion, selectedImage, siteUrl });

    const entry = {
      slug: writer.slug,
      title: writer.title,
      url: `${siteUrl}/blog/${writer.slug}.html`,
      city: city.name,
      service: service.name,
      image: selectedImage,
      publishedAt: new Date().toISOString()
    };

    const newBlogIndex = upsertBlogIndex(blogIndexJson, entry);
    const newSitemap = updateSitemapXml(sitemapXml, siteUrl, writer.slug);
    const newPubState = updatePublicationState(publicationStateJson, writer, city, service);
    const newPending = removeApproval(pendingJson, city.slug, service.slug);

    const writes = [];
    writes.push(await github.writeFile(`blog/${writer.slug}.html`, html, `feat(blog): publish ${writer.slug}`));
    writes.push(await github.writeFile(`content/auto/${writer.slug}.md`, md, `chore(blog): update markdown for ${writer.slug}`));
    writes.push(await github.writeFile("content/auto/blog-index.json", JSON.stringify(newBlogIndex, null, 2) + "\n", `chore(blog): update blog index for ${writer.slug}`, blogIndexFile.sha || undefined));
    writes.push(await github.writeFile("sitemap.xml", newSitemap, `chore(blog): update sitemap for ${writer.slug}`, sitemapFile.sha || undefined));
    writes.push(await github.writeFile("agent/state/publication-state.json", JSON.stringify(newPubState, null, 2) + "\n", `chore(blog): update publication state ${todayIsoBerlin()}`, publicationStateFile.sha || undefined));
    writes.push(await github.writeFile("agent/state/pending-approvals.json", JSON.stringify(newPending, null, 2) + "\n", `chore(blog): consume approval for ${writer.slug}`, pendingFile.sha || undefined));

    return respond({
      ok: true,
      mode: "publish-approved",
      approvalUsed: approval,
      article: {
        slug: writer.slug,
        title: writer.title,
        url: `${siteUrl}/blog/${writer.slug}.html`,
        image: selectedImage
      },
      duplicate,
      commits: writes.map(x => x?.commit?.sha).filter(Boolean)
    });
  } catch (err) {
    return respond({ ok: false, error: err?.message || String(err) }, 500);
  }
}
